package co.vinod.mait.dao.impl;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import co.vinod.mait.dao.DaoException;
import co.vinod.mait.dao.PersonDao;
import co.vinod.mait.entity.Person;
import co.vinod.mait.util.DbUtil;

public class JdbcPersonDao implements PersonDao {

	@Override
	public void addPerson(Person person) throws DaoException {
		Connection conn = null;
		PreparedStatement stmt = null;
		try {
			String sql = "insert into person values(?,?,?,?,?)";
			conn = DbUtil.getConnection();			
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, person.getId());
			stmt.setString(2, person.getFirstName());
			stmt.setString(3, person.getLastName());
			stmt.setString(4, person.getPhone());
			stmt.setString(5, person.getEmail());
			stmt.executeUpdate();
		} catch (Exception e) {
			throw new DaoException(e);
		} finally {
			DbUtil.releaseResource(conn, stmt, null);
		}
	}

	@Override
	public Person getPerson(int id) throws DaoException {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			String sql = "select * from person where id=?";
			conn = DbUtil.getConnection();			
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, id);
			rs = stmt.executeQuery();
			if(rs.next()){
				Person person = getPersonFromResultSet(rs);
				return person;
			}
			
		} catch (Exception e) {
			throw new DaoException(e);
		} finally {
			DbUtil.releaseResource(conn, stmt, rs);
		}
		return null;
	}


	@Override
	public void updatePerson(Person person) throws DaoException {

	}

	@Override
	public void deletePerson(int id) throws DaoException {
		Connection conn = null;
		PreparedStatement stmt = null;
		try {
			String sql = "delete from person where id= ?";
			conn = DbUtil.getConnection();			
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, id);
			if(stmt.executeUpdate()==0){
				throw new DaoException("No data found!");
			}
		} catch (Exception e) {
			throw new DaoException(e);
		} finally {
			DbUtil.releaseResource(conn, stmt, null);
		}
	}

	@Override
	public List<Person> getAllPersons() throws DaoException {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		List<Person> list = new ArrayList<>();
		
		try {
			String sql = "select * from person";
			conn = DbUtil.getConnection();			
			stmt = conn.prepareStatement(sql);
			rs = stmt.executeQuery();

			while(rs.next()){
				Person person = getPersonFromResultSet(rs);
				list.add(person);
			}
			
		} catch (Exception e) {
			throw new DaoException(e);
		} finally {
			DbUtil.releaseResource(conn, stmt, rs);
		}
		return list;
	}

	@Override
	public Person getPersonByPhone(String phone) throws DaoException {
		return null;
	}


	private Person getPersonFromResultSet(ResultSet rs) throws SQLException {
		Person person = new Person();
		person.setId(rs.getInt("id"));
		person.setFirstName(rs.getString("firstname"));
		person.setLastName(rs.getString("lastname"));
		person.setPhone(rs.getString("phone"));
		person.setEmail(rs.getString("email"));
		return person;
	}
}
