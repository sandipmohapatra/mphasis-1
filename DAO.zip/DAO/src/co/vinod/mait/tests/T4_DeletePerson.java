package co.vinod.mait.tests;

import co.vinod.mait.dao.DaoException;
import co.vinod.mait.dao.PersonDao;
import co.vinod.mait.dao.impl.JdbcPersonDao;

public class T4_DeletePerson {

	public static void main(String[] args) throws DaoException {
		
		PersonDao dao = new JdbcPersonDao();
		int id=101;
		
		dao.deletePerson(id);
		System.out.println("Succeeded!");
	}

}
