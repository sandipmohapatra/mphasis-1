package com.nt.repo;

import org.springframework.data.repository.CrudRepository;

import com.nt.entity.JobSeekerInfo;

public interface JobSeekerInfoRepo extends CrudRepository<JobSeekerInfo, Integer> {

}
