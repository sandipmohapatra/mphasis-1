package com.nt.model;

import org.springframework.web.multipart.MultipartFile;

import lombok.Data;

public class JobSeeker {
	private String jsName;
	private  String jsQlfy;
	private MultipartFile photo;
	public String getJsName() {
		return jsName;
	}
	public void setJsName(String jsName) {
		this.jsName = jsName;
	}
	public String getJsQlfy() {
		return jsQlfy;
	}
	public void setJsQlfy(String jsQlfy) {
		this.jsQlfy = jsQlfy;
	}
	public MultipartFile getPhoto() {
		return photo;
	}
	public void setPhoto(MultipartFile photo) {
		this.photo = photo;
	}
	public MultipartFile getResume() {
		return resume;
	}
	public void setResume(MultipartFile resume) {
		this.resume = resume;
	}
	private MultipartFile resume;

}
