import java.util.*;

public class ShapeFactory {

	public Shape getShape (String shapeType)
	{
		if(shapeType == null)
			return null;
		if(shapeType.equalsIgnoreCase("circle"))
			return new Circle();
		else if(shapeType.equalsIgnoreCase("rectangle"))
			return new Rectangle();
		else if(shapeType.equalsIgnoreCase("square"))
			return new Square();
		return null;
	}
	
	public static void main(String[] main)
	{
		Scanner on=new Scanner(System.in);
		System.out.println("Enter the Shape");
		String shp=on.next();
		ShapeFactory sf = new ShapeFactory();
		Shape shape = sf.getShape(shp);
		shape.draw();
		
		Shape shape1 = sf.getShape("Square");//Shape is a super class and interface.//sf is main class object
											//getShape() takes a class as parameter and we call the method in the class
		shape1.draw();
		
		
	}
}
