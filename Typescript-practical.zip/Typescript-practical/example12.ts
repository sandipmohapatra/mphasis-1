let msg:string = "Welcome to javaScript. You are learning javaScript String Methods.";
console.log(msg);
let newString:string = msg.replace(/javascript/gi, "TypeScript");
console.log(newString);
