var products = ["TV", "Mobile", "Shoe"];
var data = [
    { Name: "TV", Price: 45000.55 },
    { Name: "Mobile", Prie: 30000.44 }
];
for (var _i = 0, products_1 = products; _i < products_1.length; _i++) {
    var product = products_1[_i];
    console.log(product);
}
for (var _a = 0, data_1 = data; _a < data_1.length; _a++) {
    var item = data_1[_a];
    console.log(item);
}
