var products;
products = ["TV", "Mobile"];
console.log(products[0]);
