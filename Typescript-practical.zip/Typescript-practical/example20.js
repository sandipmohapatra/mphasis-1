var Name = "Samsung TV";
var Price = 50000.34;
if (Price == undefined) {
    console.log("Name=" + Name);
}
else {
    console.log("Name=" + Name + "\nPrice=" + Price);
}
