 console.log("Welcome to TypeScript");
 console.log("Hello ! World");