interface CustomArray {
    [index:number]:string;
}
let products: CustomArray;
products = ["TV", "Mobile"];
console.log(products[0]);
