let Name:string = "Samsung TV";
let Price:number = 45000.55;
let isInStock:boolean = true;
console.log(`Name=${Name}\nPrice=${Price}\nStock=${(isInStock==true)?"Available":"Out of Stock"}`);
