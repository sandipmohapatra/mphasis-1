let values:number[] = [];
values["0"]=30;
values["1"]=50;
console.log(values["1"]);
