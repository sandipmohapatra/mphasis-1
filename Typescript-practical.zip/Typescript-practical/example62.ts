function PrintMessage():void{
   console.log("Welcome to TypeScript");
   console.log("This is second line");
   console.log("This is incomplete don't execute");
   return;
   console.log("This is pending");
}
PrintMessage();
