let product = new Map([
    [1, "Samsung TV"],
    [2, "Nike Causuals"]
]);
console.log(product.get(1));       
console.log(product.size); 
product.delete(1);
product.has(3);         
