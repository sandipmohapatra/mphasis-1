package in.nit.runner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import in.nit.model.Employee;

@Component
public class TestLeagacytechRunner implements CommandLineRunner {
	@Autowired
	private EntityManagerFactory emf;
	
	@Override
	public void run(String... args) throws Exception {
		EntityManager em=emf.createEntityManager();
		EntityTransaction et=em.getTransaction();
		et.begin();
		
		Employee e1=new Employee(12, "AC", 3.9);
		Employee e2=new Employee(10, "AA", 3.3);
		
		em.persist(e1); //save
		em.persist(e2);
		
		Employee e3=em.find(Employee.class, 10); //select
		System.out.println(e3);
		
		e1.setEmpName("NEW NAME");
		em.merge(e1); //update
		
		em.remove(e2); //delete 
		
		et.commit();
		
	}

}
