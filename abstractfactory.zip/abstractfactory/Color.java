package com.design.abstractfactory;

public interface Color {
     void fill();
}
