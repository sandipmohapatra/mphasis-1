package com.design.abstractfactory;

public class AbstractFactoryPatternDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		AbstractFactory shapeFactory = FactoryProducer.getFactory("shape");
		shapeFactory.getShape("circle").draw();
		
		AbstractFactory colorFactory = FactoryProducer.getFactory("color");
		colorFactory.getColor("red").fill();
	}

}
