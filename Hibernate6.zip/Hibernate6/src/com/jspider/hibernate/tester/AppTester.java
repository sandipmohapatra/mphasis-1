package com.jspider.hibernate.tester;

import com.jspider.hibernate.dao.SportsDAO;
import com.jspider.hibernate.dto.SportsDTO;

public class AppTester {
public static void main(String[] args) {
	SportsDTO dto=new SportsDTO();
	dto.setName("FootBall");
	dto.setNoOfPlayers(10);
	dto.setType("Out door");
	SportsDAO dao=new SportsDAO();
	dao.saveSports(dto);
}
}
